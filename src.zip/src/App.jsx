import React from "react";
import Container from "./components/Container";
import Header from "./components/header/Header";

const App = () => {
  return (
    <>
      <Header />
      <main>

      </main>
    </>
  );
};

export default App;