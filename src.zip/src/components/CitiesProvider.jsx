import React, { useState } from "react";
import { CitiesContext } from "../utils/contexts/citiesContext";
import { loadCities } from "../utils/saveCities";

const CitiesProvider = ({ children }) => {
  const [cities, setCities] = useState(loadCities);
  // {
  //   id: "1",
  //   city: "Prague",
  //   country: "Czech Republic",
  //   time: "67",
  //   date: {
  //     date: "13.10.2023",
  //     day: "Friday",
  //   },
  //   img: "",
  //   temperature: {
  //     celsius: "12",
  //     fahrenheit: "120",
  //   },
  //   isLiked: false,
  // },

  const [weatherDetails, setWeatherDetails] = useState({
    type: null,
    cityId: null,
  });

  return (
    <CitiesContext.Provider
      value={{
        cities,
        setCities,
        weatherDetails,
        setWeatherDetails,
      }}
    >
      {children}
    </CitiesContext.Provider>
  );
};

export default CitiesProvider;
