import React, { useState } from "react";
import DaysItem from "./DaysItem";
import { useCities } from "../../utils/contexts/citiesContext";
import { Swiper, SwiperSlide } from "swiper/react";

import "swiper/css";

const DaysItems = () => {
  const { cities, setCities, weatherDetails, setWeatherDetails } = useCities();

  const handleLike = (id) => {
    setCities((prevCities) =>
      prevCities.map((city) =>
        city.id === id ? { ...city, isLiked: !city.isLiked } : city,
      ),
    );
  };

  //   const addCity = (city) => {
  //     setCities(prevCities => ([...prevCities, {
  //         id: "asdasdasdasd",
  //         city: city
  //     }]))
  //   }

  const handleCurrentVisible = (id) => {
    setWeatherDetails({
      type: "current",
      cityId: id,
    });
  };

  const handleHourlyVisible = () => {};

  const handleEightDaysVisible = () => {};

  return (
    <Swiper
      spaceBetween={20}
      slidesPerView={1}
      breakpoints={{
        674: {
          slidesPerView: 2,
        },
        1200: {
          slidesPerView: 3,
        },
      }}
      className="flex flex-row justify-between"
    >
      {/* <ul
      className="
      flex flex-row justify-between"
    > */}
      {cities.map((city, index) => {
        return (
          <DaysItem
            key={city.id || index}
            city={city}
            onLike={handleLike}
            className="w-full"
            onVisibleCurrent={handleCurrentVisible}
            onVisibleHourly={handleHourlyVisible}
            onVisibleEightDays={handleEightDaysVisible}
          />
        );
      })}
      {/* </ul> */}
    </Swiper>
  );
};

export default DaysItems;
