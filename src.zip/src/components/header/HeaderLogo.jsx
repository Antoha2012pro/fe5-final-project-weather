import React from 'react'

const HeaderLogo = ({}) => {
  return (
    <a href="">
        <img src="/assets/logo.webp" alt="" className='w-8.5'/>
    </a>
  )
}

export default HeaderLogo
