import React, { useEffect, useState } from "react";
import Container from "../Container";
import HeaderLogo from "./HeaderLogo";
import HeaderMenuButton from "./HeaderMenuButton";
import HeaderMenu from "./HeaderMenu";

const Header = ({}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen((prevState) => !prevState);
  };

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) setIsMenuOpen(false);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <>
      <header className="py-3.5 z-10">
        <Container className="flex justify-between items-center">
          <HeaderLogo />

          <HeaderMenuButton onClick={toggleMenu} />
        </Container>
      </header>
      {isMenuOpen && (
        <HeaderMenu isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      )}
    </>
  );
};

export default Header;
