import React from "react";
import HeaderNav from "./HeaderNav";
import Container from "../Container";
import HeaderSign from "./HeaderSign";
import { cn } from "../../utils/cn";

const HeaderMenu = ({isMenuOpen, setIsMenuOpen}) => {
  return (
    <div className={cn('bg-linear-to-b from-[#c5c5c5] to-[#E6E6E6] transition-all -z-5', isMenuOpen ? "translate-y-0" : "-translate-y-full")}>
      <Container className="py-7.5 flex items-center justify-between">
        <HeaderNav isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} className="" isMenu={true} />
        <HeaderSign isMenu={true} />
      </Container>
    </div>
  );
};

export default HeaderMenu;
