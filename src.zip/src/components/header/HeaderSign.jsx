import React from 'react'
import { cn } from '../../utils/cn'
import HeaderAvatar from './HeaderAvatar'
import HeaderSignUpButton from './HeaderSignUpButton'

const HeaderSign = ({className = '', isMenu = false}) => {
  return (
    <div className={cn('flex items-center', isMenu ? 'flex-col gap-3.75' : 'flex-row')}>
       <HeaderAvatar />
       <HeaderSignUpButton />
    </div>
  )
}

export default HeaderSign
