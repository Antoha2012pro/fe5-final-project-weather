import { ChevronDown } from "lucide-react";
import React from "react";

const HeaderMenuButton = ({onClick}) => {
  return (
    <div>
      <button onClick={onClick} className="md:hidden flex">
        <span className="font-alternates font-medium text-[10px]">Menu</span>
        <ChevronDown size={15} />
        </button>
    </div>
  );
};

export default HeaderMenuButton;
