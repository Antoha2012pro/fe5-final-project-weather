import {
  Sun,
  CloudSun,
  Cloud,
  Cloudy,
  CloudRain,
  CloudDrizzle,
  CloudLightning,
  Snowflake,
  CloudFog,
} from "lucide-react";

const icons = {
  "clear sky": Sun,
  "few clouds": CloudSun,
  "scattered clouds": Cloud,
  "broken clouds": Cloudy,
  "overcast clouds": Cloudy,
  "light rain": CloudDrizzle,
  "moderate rain": CloudRain,
  rain: CloudRain,
  drizzle: CloudDrizzle,
  thunderstorm: CloudLightning,
  snow: Snowflake,
  mist: CloudFog,
  fog: CloudFog,
  haze: CloudFog,
};

export const weatherIcon = (condition) => {
  const key = condition?.toLowerCase();
  return icons[key] || Sun;
};